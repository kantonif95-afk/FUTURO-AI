FUTURO AI – PROYECTO ANDROID DE PRUEBA

IMPORTANTE:
- Este ZIP contiene el PROYECTO FUENTE Android, no un APK ya compilado.
- Está preparado como aplicación Android sencilla que abre la práctica incluida.
- La versión de prueba guarda cuentas y resultados solamente en el teléfono (almacenamiento local).
- No tiene sincronización en la nube ni un panel remoto para ver estudiantes desde otros teléfonos.
- El PIN demostrativo del panel local es FUTURO2026.
- No ingreses datos personales reales ni contraseñas que uses en otros servicios.
- El banco actual es una muestra inicial de preguntas repetidas para completar 20 por práctica; no es todavía un banco oficial ni definitivo.

PARA GENERAR EL APK EN LA NUBE:
1. Crea una cuenta en GitHub desde el navegador: https://github.com
2. Crea un repositorio nuevo llamado FUTURO_AI.
3. Sube el contenido de este ZIP al repositorio (extrae primero el ZIP).
4. Entra a https://codemagic.io y conecta GitHub.
5. Selecciona el repositorio FUTURO_AI y configura el flujo Android.
6. Ejecuta el build. El archivo generado será app-debug.apk.

NOTA TÉCNICA:
Este proyecto incluye codemagic.yaml. Si Codemagic solicita configuración adicional de Gradle Wrapper, el servicio puede requerir agregar el Gradle Wrapper estándar compatible con Android Gradle Plugin 8.7.3.
